<!-- start: page -->
<?php
			


$result = $this->db->get_where( 'incomes', array('year' => '2018') )->result_array();

   foreach($result as $row):

	$tickets = $tickets + $row['tickets'];
	$system = $system + $row['system'];
	$actual = $actual + $row['actual'];
	$variance = $system - $actual;
	
	
	$date = $row['date']; 
													
	 if($date == '2018-01-01')
		$jansys = $row['system'];	
		
	 else if ($date == '2018-02-01')
		$febsys = $row['system'];
	else if ($date == '2018-03-01')
		$marsys = $row['system'];
	else if ($date == '2018-04-01')
		$aprsys = $row['system'];
	else if ($date == '2018-05-01')
		$maysys = $row['system'];
	else if ($date == '2018-06-01')
		$junsys = $row['system'];
	else if ($date == '2018-07-01')
		$julsys = $row['system'];
	else if ($date == '2018-08-01')
		$augsys = $row['system'];
	else if ($date == '2018-09-01')
		$sepsys = $row['system'];
	else if ($date == '2018-10-01')
		$octsys = $row['system'];
	else if ($date == '2018-11-01')
		$novsys = $row['system'];
	else if ($date == '2018-12-01')
		$decsys = $row['system'];										
	
	 if($date == '2018-01-01')
		$janact = $row['actual'];	 
	 else if ($date == '2018-02-01')
		$febact = $row['actual'];
	else if ($date == '2018-03-01')
		$maract = $row['actual'];
	else if ($date == '2018-04-01')
		$apract = $row['actual'];
	else if ($date == '2018-05-01')
		$mayact = $row['actual'];
	else if ($date == '2018-06-01')
		$junact = $row['actual'];
	else if ($date == '2018-07-01')
		$julact = $row['actual'];
	else if ($date == '2018-08-01')
		$augact = $row['actual'];
	else if ($date == '2018-09-01')
		$sepact = $row['actual'];
	else if ($date == '2018-10-01')
		$octact = $row['actual'];
	else if ($date == '2018-11-01')
		$novact = $row['actual'];
	else if ($date == '2018-12-01')
		$decact = $row['actual'];	
	endforeach;	
	
?>

			
			
			<div class="row">
			
									
	<div class="col-md-3" data-appear-animation="bounceInUp">
		
		<section class="panel panel-featured-left panel-featured-primary">
			<div class="panel-body">
				<div class="widget-summary widget-summary-sm">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-primary">
							<i class="fa fa-car"></i>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo get_phrase('tickets_sold');?></h4>
							<div class="info">
								
								<strong class="amount"><?php echo $tickets; ?></strong>
								<span class="text-primary text-uppercase"><?php echo get_phrase('-_2018');?></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	
		<div class="col-md-3" data-appear-animation="bounceInUp">
		
		<section class="panel panel-featured-left panel-featured-success">
			<div class="panel-body">
				<div class="widget-summary widget-summary-sm">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-success">
							<i class="fa fa-desktop"></i>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo get_phrase('total_system');?></h4>
							<div class="info">
								<span class="text-success text-uppercase">E</span>
								<strong class="amount"><?php echo number_format($system, 2, '.', ' ') ?></strong>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
		<div class="col-md-3" data-appear-animation="bounceInUp">
		
		<section class="panel panel-featured-left panel-featured-info">
			<div class="panel-body">
				<div class="widget-summary widget-summary-sm">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-info">
							<i class="fa fa-database"></i>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo get_phrase('total_actual');?></h4>
							<div class="info">
								<span class="text-info text-uppercase">E</span>
								<strong class="amount"> <?php echo number_format($actual, 2, '.', ' ') ?></strong>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	
		<div class="col-md-3" data-appear-animation="bounceInUp">
		
		<section class="panel panel-featured-left panel-featured-secondary">
			<div class="panel-body">
				<div class="widget-summary widget-summary-sm">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-secondary">
							<i class="fa fa-arrow-down"></i>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo get_phrase('total_variance');?></h4>
							<div class="info">
								<span class="text-secondary text-uppercase">E</span>
								<strong class="amount"><?php echo number_format($variance, 2, '.', ' ') ?></strong>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
				
			
			</div>

					<div class="row">
				
					
						<div class="col-lg-7" data-appear-animation="bounceIn">
							
							<section class="panel">
								<header class="panel-heading">
									
						
										<h2 class="panel-title">Total Revenue Chart </h2>
						
									</header>
								<div class="panel-body">
									<div class="row">
										<div class="col-lg-12" data-appear-animation="fadeInRightBig">
											
																		
											<!-- Morris: Line -->
										<div class="chart chart-md" id="morrisLine"></div>
										<script type="text/javascript">
						
											var morrisLineData = [{
												y: '2018-01-01',
												a:  <?php echo  $jansys ?>,
												b:  <?php echo  $janact ?>
											}, {
												y: '2018-02-01',
												a:  <?php echo  $febsys ?>,
												b:  <?php echo  $febact ?>
											}, {
												y: '2018-03-01',
												a:  <?php echo  $marsys ?>,
												b:  <?php echo  $maract ?>
											}, {
												y: '2018-04-01',
												a:  <?php echo  $aprsys ?>,
												b:  <?php echo  $apract ?>
											}, {
												y: '2018-05-01',
												a:  <?php echo  $maysys ?>,
												b:  <?php echo  $mayact ?>
											}, {
												y: '2018-06-01',
												a:  <?php echo  $junsys ?>,
												b:  <?php echo  $junact ?>
											}, {
												y: '2018-07-01',
												a:  <?php echo  $julsys ?>,
												b:  <?php echo  $julact ?>
											}, {
												y: '2018-08-01',
												a:  <?php echo  $augsys ?>,
												b:  <?php echo  $augact ?>
											}, {
												y: '2018-09-01',
												a:  <?php echo  $sepsys ?>,
												b:  <?php echo  $sepact ?>
											},{
												y: '2018-10-01',
												a:  <?php echo  $octsys ?>,
												b:  <?php echo  $octact ?>
											},{
												y: '2018-11-01',
												a:  <?php echo  $novsys ?>,
												b:  <?php echo  $novact ?>
											},{
												y: '2018-12-01',
												a: <?php echo  $decsys ?>,
												b: <?php echo  $decact ?>
											}];
						
											// See: assets/javascripts/ui-elements/examples.charts.js for more settings.
						
										</script>
						
										
					
					
									<hr class="solid short mt-lg">
												<div class="row">
													<div class="col-md-4">
														<div class="h4 text-weight-bold mb-none mt-lg">E <?php echo number_format($system, 2, '.', ' ') ?></div>
														<p class="text-xs text-primary mb-none">System Cash </p>
													</div>
													<div class="col-md-4">
														<div class="h4 text-weight-bold mb-none mt-lg">E <?php echo number_format($actual, 2, '.', ' ') ?></div>
														<p class="text-xs text-primary mb-none">Actual Cash</p>
													</div>
													<div class="col-md-4">
														<div class="h4 text-weight-bold mb-none mt-lg">E <?php echo number_format($variance, 2, '.', ' ') ?></div>
														<p class="text-xs text-primary mb-none">Variance Cash</p>
													</div>
												</div>
												
												</div>
										</div>
									</div>
					</section>
					
					</div>
					
					<div class="col-lg-5" data-appear-animation="bounceInLeft">
							<section class="panel">
							
							<header class="panel-heading">
									<div class="panel-actions">
									</div>
					
									<h2 class="panel-title">Tickets / Sales - 2018</h2>
								</header>	
											<div class="panel-body">
												<div class="chart chart-sm" id="flotDashSales1" style="height: 352px;"></div>

							<!-- Flot: Earning Graph -->
							<script>
								
	var flotDashSales1Data = [{
		 data: [
	
						
						<?php 
						$total=0;
						
						    foreach($result as $data ):
						        $nmonth=$data['month'];
						        $ntotal=$data['tickets'];
						 // echo $month.",".$total;
						?>
						
				    ['<?php echo $nmonth?>', <?php echo $ntotal;?>],
				
					<?php
				       endforeach;
					?> 
				
					    
					     ],
					color: "#2baab1"
			        }];
					</script>
													
															<hr class="solid short mt-lg">
												<div class="row">
													<div class="col-md-3">
														<div class="h4 text-weight-bold mb-none mt-lg">153053</div>
														<p class="text-xs text-primary mb-none">30 Minutes</p>
													</div>
													<div class="col-md-3">
														<div class="h4 text-weight-bold mb-none mt-lg">30145</div>
														<p class="text-xs text-primary mb-none">1 Hour</p>
													</div>
													<div class="col-md-3">
														<div class="h4 text-weight-bold mb-none mt-lg">5997</div>
														<p class="text-xs text-primary mb-none">2 Hours</p>
													</div>
													<div class="col-md-3">
														<div class="h4 text-weight-bold mb-none mt-lg">19053</div>
														<p class="text-xs text-primary mb-none">All Day</p>
													</div>
												</div>
												
												
											</div>
										</section>
						</div>
						
						
					<hr class="solid short mt-lg">
					
											
											
					
							
			</div>			
										
							
							
										
							
					
				
	
						<!-- start: 2018 Collections -->
					<div class="row">
						<div class="col-md-12 col-lg-12 col-xl-6">
							<section class="panel panel-featured panel-featured-primary">
								<div class="panel-body">
								
								<header class="panel-heading panel-transparent">
								
					
									<h2 class="panel-title">System / Income - 2018</h2>
								</header>
									
									<div class="row">
							<div class="col-lg-8">
							<section class="panel">
									
									<div class="panel-body">
						
									
										
										
											<?php
			
												$incount = $this->db->get_where( 'incomes', array('year' =>'2019' ) )->result_array();
												foreach ( $incount as $rows ): 
												
												$system2 = $system2 + $rows['system'];
												$actual2 = $actual2 + $rows['actual'];
												$variance2 = $system2 - $actual2;
												
											$month = $rows['month']; 												
											 if($month == 'Jan')
											 $njan = $rows['system'];
											 else if ($month == 'Feb')
											 $nfeb = $rows['system'];
											 else if ($month == 'Mar')
											 $nmar = $rows['system'];
											 else if ($month == 'Apr')
											 $napr = $rows['system'];
											 else if ($month == 'May')
											 $nmay = $rows['system'];
											 else if ($month == 'Jun')
											 $njun = $rows['system']; 
											 else if ( $month == 'Jul' )
											 $njul = $rows['system'];
											 else if ( $month == 'Aug' )
											 $naug = $rows['system'];
											 else if ( $month == 'Sep' )
											 $nsep = $rows['system'];
											 else if ( $month == 'Oct' )
											 $noct = $rows['system'];
											 else if ( $month == 'Nov' )
											 $nnov = $rows['system'];
											 else if ( $month == 'Dec' )
											 $ndec = $rows['system'];
											 
											 $month = $rows['month']; 												
											 if($month == 'Jan')
											 $njan2 = $rows['actual'];
											 else if ($month == 'Feb')
											 $nfeb2 = $rows['actual'];
											 else if ($month == 'Mar')
											 $nmar2 = $rows['actual'];
											 else if ($month == 'Apr')
											 $napr2 = $rows['actual'];
											 else if ($month == 'May')
											 $nmay2 = $rows['actual'];
											 else if ($month == 'Jun')
											 $njun2 = $rows['actual']; 
											 else if ( $month == 'Jul' )
											 $njul2 = $rows['actual'];
											 else if ( $month == 'Aug' )
											 $naug2 = $rows['actual'];
											 else if ( $month == 'Sep' )
											 $nsep2 = $rows['actual'];
											 else if ( $month == 'Oct' )
											 $noct2 = $rows['actual'];
											 else if ( $month == 'Nov' )
											 $nnov2 = $rows['actual'];
											 else if ( $month == 'Dec' )
											 $ndec2 = $rows['actual'];
									
											endforeach;
											
												?>
											<!-- Morris: Area -->
										<div class="chart chart-md" id="morrisStacked"></div>
										
									<script type="text/javascript">
										var morrisStackedData = [
											
										<?php
								
										$umnyaka = date('Y');
										
										$this->db->select("*");
                                		$this->db->where('year',$umnyaka);
                                	    $this->db->from('inmonths');
                                	    $q = $this->db->get();
                                	    $incount = $q->result_array();
										
											
								foreach ($incount as $moh): 
												
								$startdates = $moh['startdate'];
								$enddates   = $moh['enddate'];
									
								
								
								$this->db->where('date >=',$startdates);
								$this->db->where('date <=',$enddates);
								$this->db->where('year',$umnyaka);
								$this->db->select_sum('actual');
								$querya = $this->db->get('dailyrecon'); 
								$actuals1 = $querya->row()->actual;
												
								$this->db->where('date >=',$startdates);
								$this->db->where('date <=',$enddates);
								$this->db->where('year',$umnyaka);
								$this->db->select_sum('total');
								$query2 = $this->db->get('dailyrecon'); 
								$totals1 = $query2->row()->total;
								
								if(!empty($actuals1)){
								$actualy = number_format($actuals1, 2, '.', '');
								}else{
								$actualy = 0;
								}
								
								if(!empty($totals1)){
								$totally = number_format($totals1, 2, '.', '');
								}else{
								$totally = 0;
								}
												
									$inyanga = date('M',strtotime($moh['startdate']));			
								  
							    ?>
										
											{
												y: "<?php echo $inyanga; ?>",
												a:  <?php echo $totally ?> ,
												b: <?php echo $actualy ?>
											}, 
											
											
											<?php endforeach; ?>
										
											];
						
											// See: assets/javascripts/ui-elements/examples.charts.js for more settings.
						
										</script>
										
										
										
								<?php
										
								$umnyaka = date('Y');
								
								$this->db->where('year',$umnyaka);
								$this->db->select_sum('actual');
								$querya = $this->db->get('dailyrecon'); 
								$actuals2018 = $querya->row()->actual;
								
								$this->db->where('year',$umnyaka);
								$this->db->select_sum('total');
								$query2 = $this->db->get('dailyrecon'); 
								$totals2018 = $query2->row()->total;
								
								
								$variance2018 = $totals2018 - $actuals2018;
										
								?>
						
							<hr class="solid short mt-lg">
												<div class="row">
													<div class="col-md-4">
														<div class="h4 text-weight-bold mb-none mt-lg">E <?php echo number_format($totals2018, 2, '.', ' ') ?></div>
														<p class="text-xs text-primary mb-none">System Cash </p>
													</div>




													<div class="col-md-4">
														<div class="h4 text-weight-bold mb-none mt-lg">E <?php echo number_format($actuals2018, 2, '.', ' ') ?></div>
														<p class="text-xs text-primary mb-none">Actual Cash</p>
													</div>
													<div class="col-md-4">
														<div class="h4 text-weight-bold mb-none mt-lg">E <?php echo number_format($variance2018, 2, '.', ' ') ?></div>
														<p class="text-xs text-primary mb-none">Variance Cash</p>
													</div>
												</div>
						
						
						
									</div>
								</section>
							</div>
					
						
						
						<div class="col-lg-4" data-appear-animation="bounceInLeft">
						
						<div class="panel-body">
						
							<!-- Morris: Donut -->
										<div class="chart chart-md" id="morrisDonut"></div>
										<script type="text/javascript">
						
											var morrisDonutData = [
											
											
											<?php
										
								$umnyaka = date('Y');
								
								//$this->db->where('date >=',$startdates);
								//$this->db->where('date <=',$enddates);
								//$this->db->where('year',$umnyaka);
								//$this->db->select('month');
								//$qa = $this->db->get('dailyrecon'); 
								//$inyanga1 = $qa->row()->month;
								
								
								foreach ($incount as $inyanga): 
								
								$inyanga1 = $inyanga['month'];
								$mstartdates = $inyanga['startdate'];
								$menddates   = $inyanga['enddate'];
								
								$this->db->where('date >=',$mstartdates);
								$this->db->where('date <=',$menddates);
								$this->db->where('year',$umnyaka);
								$this->db->where('month',$inyanga1);
								$this->db->select_sum('actual');
								$querya1 = $this->db->get('dailyrecon'); 
								$actual8 = $querya1->row()->actual;
								
								if(!empty($actual8)){
								$actualm =  number_format($actual8, 2, '.', '');
								}else{
								$actualm = 0;
								}
								
										
								?>						
											
											{
												label: "<?php echo $inyanga1; ?>",
												value: "<?php echo $actualm ?>"
											}, 
											
											<?php endforeach; ?>
											];
						
											// See: assets/javascripts/ui-elements/examples.charts.js for more settings.
						
										</script>
						
						</div>
					</div>
					
				</div>
										
								</div>
								
							</section>
						</div>
					</div>
							
						
						<div class="row">			
						
	
								<div class="col-md-6 col-lg-12 col-xl-6" data-appear-animation="bounceIn">
		<div class="row">
			<div class="col-md-12 col-lg-6 col-xl-6">
				<section class="panel panel-featured-left panel-featured-primary">
					<div class="panel-body">
						<div class="widget-summary">
							<div class="widget-summary-col widget-summary-col-icon">
								<div class="summary-icon bg-primary">
									<i class="fa fa-ticket"></i>
								</div>
							</div>
							
							
							<?php
							
							$allTickets = $this->db->count_all('tickets');
							
							
							?>
							<div class="widget-summary-col">
								<div class="summary">
									<h4 class="title">
										<?php echo get_phrase('tickets');?>
									</h4>
									<div class="info">
										<strong class="amount">
										<?php echo 264776 + $allTickets ?>
										</strong>
									</div>
								</div>
								<div class="summary-footer">
									<span class="text-muted text-uppercase">All Tickets</span>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
			<div class="col-md-12 col-lg-6 col-xl-6" data-appear-animation="bounceIn">
				<section class="panel panel-featured-left panel-featured-primary">
					<div class="panel-body">
						<div class="widget-summary">
							<div class="widget-summary-col widget-summary-col-icon">
								<div class="summary-icon bg-primary">
									<i class="fa fa-users"></i>
								</div>
							</div>
							<div class="widget-summary-col">
								<div class="summary">
									<h4 class="title">
										<?php echo get_phrase('marshals');?>
									</h4>
									<div class="info">
										<strong class="amount">
											<?php echo $this->db->count_all('marshal'); ?>
										</strong>
									</div>
								</div>
								<div class="summary-footer">
									<span class="text-muted text-uppercase">Total Marshals</span>
								</div>
							</div>
						</div>


					</div>
				</section>
			</div>
			<div class="col-md-12 col-lg-6 col-xl-6" data-appear-animation="bounceIn">
				<section class="panel panel-featured-left panel-featured-primary">
					<div class="panel-body">
						<div class="widget-summary">
							<div class="widget-summary-col widget-summary-col-icon">
								<div class="summary-icon bg-primary">
									<i class="fa fa-tablet"></i>
								</div>
							</div>
							<div class="widget-summary-col">
								<div class="summary">
									<h4 class="title">
										<?php echo get_phrase('devices');?>
									</h4>
									<div class="info">
										<strong class="amount">
											<?php echo $this->db->count_all('device');?>
										</strong>
									</div>
								</div>
								<div class="summary-footer">
									<span class="text-muted text-uppercase">Total Devices</span>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
			<div class="col-md-12 col-lg-6 col-xl-6" data-appear-animation="bounceIn">
				<section class="panel panel-featured-left panel-featured-primary">
					<div class="panel-body">
						<div class="widget-summary">
							<div class="widget-summary-col widget-summary-col-icon">
								<div class="summary-icon bg-primary">
									<i class="fa fa-car"></i>
								</div>
							</div>
								<div class="widget-summary-col">
								<div class="summary">
									<h4 class="title">
										<?php echo get_phrase('baysets');?>
									</h4>
									<div class="info">
										<strong class="amount">
											<?php echo $this->db->count_all('bays');?>
										</strong>
									</div>
								</div>
								<div class="summary-footer">
									<span class="text-muted text-uppercase">Bay Sets</span>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>
	</div>
	
	<div class="col-lg-6" data-appear-animation="bounceInLeft">
							<section class="panel">
											<header class="panel-heading">
												<div class="panel-actions">
													<a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
													<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
												</div>
						
												<h2 class="panel-title">Bays on Streets </h2>
											</header>
											<div class="panel-body">
												<div class="row text-center">
													<div class="col-md-6">
														<div class="circular-bar">
															<div class="circular-bar-chart" data-percent="63" data-plugin-options='{ "barColor": "#0088CC", "delay": 300 }'>
																<strong>Left Bays</strong>
																<label><span class="percent">63></span>%</label>
															</div>
														</div>
													</div>
													<div class="col-md-6">
														<div class="circular-bar">
															<div class="circular-bar-chart" data-percent="34" data-plugin-options='{ "barColor": "#2BAAB1", "delay": 600 }'>
																<strong>Right Bays</strong>
																<label><span class="percent">34</span>%</label>
															</div>
														</div>
													</div>
												</div>
											</div>
										</section>	
							</div>
							
							<div class="col-xl-3 col-lg-6" data-appear-animation="bounceInUp">
							<section class="panel panel-transparent">
								
											
								<div class="panel-body">
									<section class="panel">
										<div class="panel-body">
											<div class="circular-bar circular-bar-xs m-none mt-xs mr-md pull-right">
												<div class="circular-bar-chart" data-percent="45" data-plugin-options='{ "barColor": "#FFAB00", "delay": 300, "size": 50, "lineWidth": 4 }'>

													<strong>Average</strong>
													<label><span class="percent">45</span>%</label>
												</div>
											</div>
											<div class="h4 text-weight-bold mb-none">345 </div>
											<p class="text-xs text-muted mb-none">Gwamile Street</p>
										</div>
									</section>
									<section class="panel">
										<div class="panel-body">
											<div class="circular-bar circular-bar-xs m-none mt-xs mr-md pull-right">
												<div class="circular-bar-chart" data-percent="36" data-plugin-options='{ "barColor": "#FFC400", "delay": 300, "size": 50, "lineWidth": 4 }'>
													<strong>Average</strong>
													<label><span class="percent">36</span>%</label>
												</div>
											</div>
											<div class="h4 text-weight-bold mb-none">279</div>
											<p class="text-xs text-muted mb-none">Dzeliwe Street</p>
										</div>
									</section>
									<section class="panel">
										<div class="panel-body">
											<div class="circular-bar circular-bar-xs m-none mt-xs mr-md pull-right">
												<div class="circular-bar-chart" data-percent="18" data-plugin-options='{ "barColor": "#FFD740", "delay": 300, "size": 50, "lineWidth": 4 }'>
													<strong>Average</strong>
													<label><span class="percent">18</span>%</label>
												</div>
											</div>
											<div class="h4 text-weight-bold mb-none">120</div>
											<p class="text-xs text-muted mb-none">Zwide Street</p>
										</div>
									</section>
								</div>
							</section>
							
							
							
						</div>
	</div>
					
<div class="row">

    <!-- CALENDAR-->
	<div class="col-md-8" data-appear-animation="bounceIn">
		<section class="panel">
			<header class="panel-heading">
				<h2 class="panel-title">
				<?php echo get_phrase('event_schedule');?>	
				</h2>
			</header>
			<div class="panel-body">
				<div id="notice_calendar"></div>
			</div>
		</section>
	</div>
	


	
<div class="col-md-4">
	<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions"></div>
			<h2 class="panel-title"><?php echo get_phrase('this_week_games_tickets_income');?></h2>
	</header>	
		<div class="panel-body">
		
		<div class="scrollable" data-plugin-scrollable style="height: 450px;">
	<div class="scrollable-content">
	<?php 
	
	$year = date('Y');
	
/*	$inmonths = $this->db->get('inmonths', 'year' => $year )->result_array());
	
	*/
		
		$this->db->select("*");
		$this->db->where('year',$year);
	    $this->db->from('inmonths');
	    $query1 = $this->db->get();
	    $inmonths = $query1->result_array();
	
	;?>
	<?php foreach($inmonths as $row):
	
			$startdate = $row['startdate'];
			$enddate   = $row['enddate'];
			
			
			
											
			$this->db->where('date >=',$startdate);
        	$this->db->where('date <=',$enddate);
        	$this->db->where('year',$year);
			$this->db->select_sum('actual');
			$querys = $this->db->get('dailyrecon'); 
			$result7 = $querys->row()->actual;
												
			
												
	?>
	
	<div class="col-md-12" data-appear-animation="bounceInUp">		
		<section class="panel panel-featured-left panel-featured-primary">
			<div class="panel-body">
				<div class="widget-summary widget-summary-sm">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-primary">
							<i class="fa fa-money"></i>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo date('F',strtotime($row['startdate'])).' -'.$row['year'].' Financials';?></h4>
							<div class="info">
								<span class="text-primary text-uppercase">E</span>
								<strong class="amount"><?php echo number_format($result7, 2, '.', ' ') ?></strong>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
<?php endforeach; ?>
</div>
</div>
		
		
		</div>
	</section>
</div>
	
	<div class="col-md-4" data-appear-animation="bounceInUp">
		
		<section class="panel panel-featured-left panel-featured-primary">
			<div class="panel-body">
				<div class="widget-summary widget-summary-sm">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-primary">
							<i class="fa fa-money"></i>
						</div>
					</div>
					
								
				<?php
			$dayincome = $this->db->get_where( 'intickets', array('date' => date('Y-m-d')) )->result_array();
			$todayincome = 0;
			foreach ( $dayincome as $row ):
			$todayincome = $todayincome + $row[ 'amount' ] ;
			endforeach;
		 ?>
						
					
					
					<div class="widget-summary-col">
						<div class="summary">
								
							<h4 class="title"><?php echo get_phrase('todays_cash');?></h4>
							<div class="info">
								<strong class="amount">E <?php echo $todayincome;?></strong><br/>
								<span class="text-primary text-uppercase"><?php echo date('Y-m-d');?></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	
</div>
	


<script>
	//CALENDAR SETTINGS
	$( document ).ready( function () {
		var calendar = $( '#notice_calendar' );
		$( '#notice_calendar' ).fullCalendar( {
			header: {
				left: 'title',
				right: 'prev,today,next'
			},

			//defaultView: 'basicWeek',
			displayEventTime : false,
			editable: false,
			firstDay: 1,
			height: 450,
			droppable: false,

			events: [
				<?php 
				$notices = $this->db->get('noticeboard')->result_array();
				
				foreach($notices as $row):
				?> {
					title: "<?php echo $row['notice_title'];?>",
					start: new Date( <?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?> ),
					end: new Date( <?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?> )
				},
				<?php 
				  endforeach
				?>
			]
		} );
	} );
</script>