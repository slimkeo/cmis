

<div class="row">

						<div class="pricing-table">
							<div class="col-lg-4">
								<div class="plan">
									<h3>January<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/januaryschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('january_stats');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
									<h3>February<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/februaryschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('february_stats');?>">View Report</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
										<h3>March<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/marchschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('march_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
										<h3>April<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/aprilschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('april_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							
							<div class="col-lg-4">
									<div class="plan">
									<h3>May<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										<li><a href="<?php echo base_url();?>index.php?admin/mayschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('may_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
									<h3>June<span>34</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/juneschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('june_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
										<h3>July<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										<li><a href="<?php echo base_url();?>index.php?admin/julyschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('july_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
									<h3>August<span>32</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/augustschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('august_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
									<h3>September<span>34</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/septemberschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('september_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
										<h3>October<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										<li><a href="<?php echo base_url();?>index.php?admin/octoberschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('october_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
									<h3>November<span>32</span></h3>
									<p>Marshals</p>
									<ul>
										
										<li><a href="<?php echo base_url();?>index.php?admin/novemberschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('november_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4">
									<div class="plan">
										<h3>December<span>35</span></h3>
									<p>Marshals</p>
									<ul>
										<li><a href="<?php echo base_url();?>index.php?admin/decemberschedule"class="btn btn-primary btn-xs" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo get_phrase('december_schedule');?>">View Schedule</a></li>
									</ul>
								</div>
							</div>
						</div>