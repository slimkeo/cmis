	<div class="mailbox-email-header mb-lg">
		<h3 class="mailbox-email-subject m-none text-weight-light">
			<?php echo get_phrase('messages'); ?>
		</h3>
	</div>

<div style="width:100%; text-align:center; padding:100px;color:#aaa;">

    <img src="<?php echo base_url(); ?>assets/images/mail-box.png" width="70">
    <br>
  
        Select a message to read
    
</div>